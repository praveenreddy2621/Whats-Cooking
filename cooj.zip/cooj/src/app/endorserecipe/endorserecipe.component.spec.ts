import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EndorserecipeComponent } from './endorserecipe.component';

describe('EndorserecipeComponent', () => {
  let component: EndorserecipeComponent;
  let fixture: ComponentFixture<EndorserecipeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EndorserecipeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EndorserecipeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
