import { Component, OnInit } from '@angular/core';
import { RecipeService } from '../recipe.service'; // Import the RecipeService
import { UserService } from '../user.service';     // Import the UserService
import { Recipe } from '../recipe.model';         // Import the Recipe model

@Component({
  selector: 'app-endorse-recipe',  // Ensure this matches the selector used in HTML
  templateUrl: './endorse-recipe.component.html',
  styleUrls: ['./endorse-recipe.component.css']
})
export class EndorseRecipeComponent implements OnInit {
  recipes: Recipe[] = [];    // Array to hold recipes
  userId: number | null = null; // User ID for endorsements

  constructor(private recipeService: RecipeService, private userService: UserService) {}

  ngOnInit(): void {
    this.loadHealthyRecipes();
    this.userId = this.userService.getUserFromStorage()?.id || null; // Get the logged-in user ID
  }

  loadHealthyRecipes(): void {
    this.recipeService.getHealthyRecipes().subscribe(
      (data: Recipe[]) => {
        this.recipes = data;
      },
      error => {
        console.error('Error fetching recipes', error);
      }
    );
  }

  endorse(recipeId: number): void {
    if (this.userId === null) {
      console.error('User not logged in');
      return;
    }

    this.recipeService.endorseRecipe(recipeId, this.userId).subscribe(
      response => {
        console.log('Recipe endorsed successfully', response);
        this.loadHealthyRecipes(); // Refresh the recipe list
      },
      error => {
        console.error('Error endorsing recipe', error);
      }
    );
  }
}
