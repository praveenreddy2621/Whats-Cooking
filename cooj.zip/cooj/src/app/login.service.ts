import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private baseUrl = 'http://localhost:8087/users'; // Update with your actual backend URL

  constructor(private http: HttpClient) {}

  // Login method
  login(emailId: string, password: string): Observable<any> {
    const loginRequest = { emailId, password };
    return this.http.post<any>(`${this.baseUrl}/v1/login`, loginRequest);
  }
  
  // Handle the login response (if needed elsewhere)
  handleLoginResponse(response: any): void {
    // Example: Store token and user details in local storage
    localStorage.setItem('authToken', response.token);  // Adjust based on actual response
    localStorage.setItem('user', JSON.stringify(response.user));  // Adjust based on actual response
  }
}
