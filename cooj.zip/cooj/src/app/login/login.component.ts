import { Component, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth/auth.component';  // Adjust the path as necessary
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  loginError: string | null = null;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {
    this.loginForm = this.fb.group({
      emailId: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { emailId, password } = this.loginForm.value;
      this.authService.login(emailId, password).subscribe(
        (        response: any) => {
          console.log('Login successful', response);
          console.log('Registration successful:', response);
          alert('Login successful');
          localStorage.setItem('user', JSON.stringify(response));
          this.router.navigate(['/dashboard']);
        },
        (        error: any) => {
          this.loginError = 'Invalid email or password';
          this.cdr.detectChanges();  // Force Angular to update the view
          console.error('Login error', error);
        }
      );
    }
  }
}
