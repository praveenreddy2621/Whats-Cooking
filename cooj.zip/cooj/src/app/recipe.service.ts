import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Recipe } from './recipe.model';

@Injectable({
  providedIn: 'root'
})
export class RecipeService {
  private baseUrl = 'http://localhost:8087/recipes'; // Ensure this URL is correct

  constructor(private http: HttpClient) {}

  getHealthyRecipes(): Observable<Recipe[]> {
    return this.http.get<Recipe[]>(`${this.baseUrl}/healthy`);
  }

  endorseRecipe(recipeId: number, userId: number): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/${recipeId}/endorse`, { userId });
  }
}
