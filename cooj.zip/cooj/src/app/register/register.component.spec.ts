import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User, UserService } from '../user.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string | null = null;

  constructor(private fb: FormBuilder, private userService: UserService) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      role: ['USER', Validators.required]  // Default role
    });
  }

  onSubmit(): void {
    if (this.registerForm.valid) {
      const user: User = this.registerForm.value;
      console.log('Form data:', user); // Print to verify form data
  
      this.userService.registerUser(user).subscribe(
        (newUser: User) => {
          console.log('User registered successfully:', newUser);
          this.registerForm.reset();
        },
        (error: any) => {
          console.error('Error registering user:', error);
          this.errorMessage = 'Error registering user: ' + (error.message || 'Unknown error');
        }
      );
    } else {
      this.errorMessage = 'Please fill out all required fields.';
    }
  }
}
