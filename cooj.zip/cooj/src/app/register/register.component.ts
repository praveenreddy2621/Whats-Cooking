import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  user = {
    username: '',
    password: '',
    email: '',
    firstName: '',
    lastName: '',
    role: 'USER'  // Default role
  };

  errorMessage: string | null = null;

  constructor(private http: HttpClient, private router: Router) {}

  onSubmit() {
    this.http.post('http://localhost:8087/users/register', this.user)
      .subscribe({
        next: (response: any) => {
          console.log('Registration successful:', response);
          alert('Registration successful');
          this.router.navigate(['/login']);
        },
        error: (error: any) => {
          console.error('Registration failed:', error);
          this.errorMessage = 'Registration failed: ' + (error.message || 'Unknown error');
        }
      });
  }
}
