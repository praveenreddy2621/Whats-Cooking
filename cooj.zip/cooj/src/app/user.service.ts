import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface User {
  id?: number;
  username: string;
  password?: string;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {
  getUserFromStorage() {
    throw new Error('Method not implemented.');
  }
  private baseURL = `http://localhost:8087/users`;

  constructor(private http: HttpClient) {}

  // Register a new user
  registerUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseURL}/register`, user)
      .pipe(catchError(this.handleError));
  }

  // Login user and get a token
  loginUser(credentials: { username: string, password: string }): Observable<any> {
    return this.http.post<any>(`${this.baseURL}/login`, credentials)
      .pipe(catchError(this.handleError));
  }

  // Get user by ID
  getUser(id: number): Observable<User> {
    return this.http.get<User>(`${this.baseURL}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Get all users
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(this.baseURL)
      .pipe(catchError(this.handleError));
  }

  // Update user details
  updateUser(id: number, userDetails: User): Observable<User> {
    return this.http.put<User>(`${this.baseURL}/${id}`, userDetails)
      .pipe(catchError(this.handleError));
  }

  // Delete user by ID
  deleteUser(id: number): Observable<void> {
    return this.http.delete<void>(`${this.baseURL}/${id}`)
      .pipe(catchError(this.handleError));
  }

  // Change user password
  changePassword(id: number, newPassword: string): Observable<User> {
    return this.http.put<User>(`${this.baseURL}/${id}/password`, newPassword, {
      headers: new HttpHeaders({ 'Content-Type': 'text/plain' })
    }).pipe(catchError(this.handleError));
  }

  // Error handling
  private handleError(error: any): Observable<never> {
    console.error('An error occurred', error);
    return throwError(error);
  }

  // Implement logout logic
  logoutUser(): void {
    localStorage.removeItem('authToken');
  }
  getUserFromStorage(): any {
    return JSON.parse(localStorage.getItem('user') || '{}'); // Replace with actual method if different
  }

  
}
