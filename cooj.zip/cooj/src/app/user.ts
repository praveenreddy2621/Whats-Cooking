export class user{
    id!: number;
    firstName!: string;
    lastName!: string;
    emailId!: string;
    role!: string;
}
