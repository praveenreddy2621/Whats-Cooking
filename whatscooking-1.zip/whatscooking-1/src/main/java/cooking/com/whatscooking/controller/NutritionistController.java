package cooking.com.whatscooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cooking.com.whatscooking.entity.Nutritionist;
import cooking.com.whatscooking.service.NutritionistService;
@CrossOrigin("http://localhost:4200")

@RestController
@RequestMapping("/nutritionists")
public class NutritionistController {

    @Autowired
    private NutritionistService nutritionistService;

    @PostMapping
    public ResponseEntity<Nutritionist> addNutritionist(@RequestBody Nutritionist nutritionist) {
        Nutritionist createdNutritionist = nutritionistService.addNutritionist(nutritionist); // Updated to match service method
        return new ResponseEntity<>(createdNutritionist, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Nutritionist> getNutritionist(@PathVariable Long id) {
        Nutritionist nutritionist = nutritionistService.getNutritionistById(id);
        if (nutritionist != null) {
            return new ResponseEntity<>(nutritionist, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Nutritionist> updateNutritionist(@PathVariable Long id, @RequestBody Nutritionist nutritionist) {
        Nutritionist updatedNutritionist = nutritionistService.updateNutritionist(id, nutritionist);
        if (updatedNutritionist != null) {
            return new ResponseEntity<>(updatedNutritionist, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNutritionist(@PathVariable Long id) {
        if (nutritionistService.getNutritionistById(id) != null) {
            nutritionistService.deleteNutritionist(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
