package cooking.com.whatscooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cooking.com.whatscooking.entity.Like;
import cooking.com.whatscooking.service.LikeService;
@CrossOrigin("http://localhost:4200")

@RestController
@RequestMapping("/likes")
public class UserLikeController {
    @Autowired
    private LikeService likeService;

    @PostMapping
    public Like addLike(@RequestBody Like like) {
        return likeService.addLike(like);
    }

    @DeleteMapping
    public void removeLike(@RequestParam Long userId, @RequestParam Long recipeId) {
        likeService.removeLike(userId, recipeId);
    }
}
//