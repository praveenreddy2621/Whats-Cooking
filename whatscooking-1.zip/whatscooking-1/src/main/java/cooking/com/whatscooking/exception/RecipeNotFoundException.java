package cooking.com.whatscooking.exception;
@SuppressWarnings("serial")
public class RecipeNotFoundException extends RuntimeException {
    public RecipeNotFoundException(String message) {
        super(message);
    }
}
