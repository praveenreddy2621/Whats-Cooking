package cooking.com.whatscooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cooking.com.whatscooking.entity.Like;

public interface LikesRepository extends JpaRepository<Like, Long> {
    boolean existsByUserIdAndRecipeId(Long userId, Long recipeId);

    Like findByUserIdAndRecipeId(Long userId, Long recipeId);
}
