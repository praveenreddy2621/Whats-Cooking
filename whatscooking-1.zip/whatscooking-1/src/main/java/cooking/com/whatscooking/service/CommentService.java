package cooking.com.whatscooking.service;

import cooking.com.whatscooking.entity.Comment;
import cooking.com.whatscooking.repository.CommentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentService {
    
    @Autowired
    private CommentsRepository commentsRepository;

    public Comment addComment(Comment comment) {
        return commentsRepository.save(comment);
    }

    public Comment getCommentById(Long id) {
        return commentsRepository.findById(id).orElse(null);
    }

    public void deleteComment(Long id) {
        commentsRepository.deleteById(id);
    }
}
