package cooking.com.whatscooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cooking.com.whatscooking.entity.Like;
import cooking.com.whatscooking.repository.LikesRepository;

@Service
public class LikeService {
    @Autowired
    private LikesRepository likesRepository;

    public Like addLike(Like like) {
        // Check if a like already exists for the given user and recipe
        if (likesRepository.existsByUserIdAndRecipeId(like.getUserId(), like.getRecipeId())) {
            throw new RuntimeException("Like already exists for this user and recipe");
        }
        return likesRepository.save(like);
    }

    public void removeLike(Long userId, Long recipeId) {
        // Find the like to delete
        Like like = likesRepository.findByUserIdAndRecipeId(userId, recipeId);
        if (like != null) {
            likesRepository.delete(like);
        } else {
            throw new RuntimeException("Like not found for this user and recipe");
        }
    }
}
