package cooking.com.whatscooking.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cooking.com.whatscooking.entity.Recipe;
import cooking.com.whatscooking.exception.RecipeNotFoundException;
import cooking.com.whatscooking.repository.RecipeRepository;

@Service
public class RecipeService {
    @Autowired
    private RecipeRepository recipeRepository;

    public Recipe addRecipe(Recipe recipe) {
        return recipeRepository.save(recipe);
    }

    public Recipe getRecipeById(Long recipeId) {
        return recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));
    }

    public Recipe updateRecipe(Long recipeId, Recipe recipeDetails) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));

        recipe.setName(recipeDetails.getName());
        recipe.setDescription(recipeDetails.getDescription());
        recipe.setIngredients(recipeDetails.getIngredients());
        recipe.setSteps(recipeDetails.getSteps());
        recipe.setEnabled(recipeDetails.isEnabled());
        recipe.setEndorsed(recipeDetails.isEndorsed()); // Update endorsed field

        return recipeRepository.save(recipe);
    }

    public void deleteRecipe(Long recipeId) {
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new RecipeNotFoundException("Recipe not found with ID: " + recipeId));
        recipeRepository.delete(recipe);
    }

    public List<Recipe> searchRecipes(String keyword) {
        return recipeRepository.findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(keyword, keyword);
    }

    public List<Recipe> filterAndSortRecipes(String filter, String sortOrder) {
        if ("name".equalsIgnoreCase(filter)) {
            return "asc".equalsIgnoreCase(sortOrder) ?
                    recipeRepository.findAllByOrderByNameAsc() :
                    recipeRepository.findAllByOrderByNameDesc();
        }
        // Add more filters as needed
        return recipeRepository.findAll();
    }

    public List<Recipe> getEndorsedRecipes() {
        return recipeRepository.findByEndorsedTrue();
    }

    public List<Recipe> getNonEndorsedRecipes() {
        return recipeRepository.findByEndorsedFalse();
    }
}
